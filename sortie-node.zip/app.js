var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const bodyParser = require('body-parser');
//引入mongodb文件
require('./models/user');
require('./models/banner');
require('./models/order');
require('./models/article');
require('./models/about');
require('./models/admin');
require('./models/magazine');

var indexRouter = require('./routes/index');
var Tools = require('./routes/tools');
// var usersRouter = require('./routes/users');


// 阿里云 accesstoken
// var OSS = require('ali-oss');
//
// let client = new OSS({
//   accessKeyId: 'LTAI4FyTu9arLttXTVyquGHH',
//   accessKeySecret: 'KGSIcqWrnRb8Wfzx062ORtAhYOGlyY',
//   bucket: '759729757',
//   region: 'oss-cn-shenzhen'
// });
//
// async function listBuckets() {
//   try {
//     let result = await client.listBuckets();
//     console.log("查看Bucket列表");
//     console.log(result);
//   } catch (err) {
//     console.log(err);
//   }
// }
// listBuckets();

let OSS = require('ali-oss');
let STS = OSS.STS;
let sts = new STS({
  // 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。
  // 强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录RAM控制台创建RAM账号。
  accessKeyId: 'LTAI4FyyU9Ki4sDgk9aQGgET',
  accessKeySecret: 'bQCGp8nu5zl3vEmV93w52WifRpe3pB'
});
let policy = {
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "oss:*",
        "oss:Put*",
        "oss:List*",
        "oss:Get*",
        "oss:ListBuckets"
      ],
      "Resource": [
        "acs:oss:*:*:759729757"
      ],
      "Condition": {}
    },
    {
      "Effect": "Allow",
      "Action": [
        "oss:*"
      ],
      "Resource": [
        "acs:oss:*:*:759729757"
      ],
      "Condition": {}
    }
  ]
};
async function assumeRole () {
  try {
    let token = await sts.assumeRole(
        'acs:ram::1549187690389385:role/759729757', policy, 15 * 60, 'test-session');
    let client = new OSS({
      region: 'oss-cn-shenzhen',
      accessKeyId: token.credentials.AccessKeyId,
      accessKeySecret: token.credentials.AccessKeySecret,
      stsToken: token.credentials.SecurityToken,
      bucket: '759729757'
    });
    console.log('AccessKeyId')
    console.log( token.credentials.AccessKeyId);
    console.log('AccessKeySecret')
    console.log( token.credentials.AccessKeySecret);
    console.log('SecurityToken')
    console.log(token.credentials.SecurityToken);

  } catch (e) {
    console.log(e);
  }
}
// assumeRole();


var app = express();

//接受跨域
app.all('*', function(req, res, next) {
  //get
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "*");
  // res.header("Access-Control-Allow-Headers", "X-Requested-With");

  //post
  res.header("Access-Control-Allow-Headers", "Content-Type, x-xsrf-token,Authorization");
  res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS,PUT');
  next();
});

app.use(bodyParser.json());//数据JSON类型
// app.use(bodyParser.urlencoded({ extended: false }));//解析post请求数据
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());


app.use('/tools', Tools);
app.use('/', indexRouter);
// app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
