'use strict'

var OSS = require('ali-oss');
var STS = OSS.STS;
var co = require('co');

var sts = new STS({
	accessKeyId: 'LTAI4FyyU9Ki4sDgk9aQGgET',
	accessKeySecret: 'bQCGp8nu5zl3vEmV93w52WifRpe3pB',
});
var rolearn = 'acs:ram::1549187690389385:role/759729757';

var policy = {
	"Statement": [
		{
			"Action": "oss:*",
			"Effect": "Allow",
			"Resource": "*"
		}
	],
	"Version": "1"
};

class Service {

	getOssToken(req, res){
		var result = co(function* () {
			var token = yield sts.assumeRole(rolearn, policy, 15 * 60, 'taoosossss');
			res.json({
				token:token.credentials
			})
		}).catch(function (err) {
			console.log('获取阿里云sts失败',err)
		});
	}
}

module.exports = new Service()
