exports.AppID = "";
exports.Secret = "";

exports.appid = "";
exports.appsecret = "";


exports.tokenKey = 'sortieMagazineMallAppByCy';
