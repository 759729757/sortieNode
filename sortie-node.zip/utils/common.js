/**
 * 共用方法放这里
 * */

exports.removeProperty = (object)=>{
    for(prop in object){
        if (object[prop]===''||!object[prop]) {
            delete object[prop]
        }
    }
}



// 判断图片类型
exports.isAssetTypeAnImage = (ext)=> {
    return [
        'png', 'jpg', 'jpeg', 'bmp', 'gif', 'webp', 'psd', 'svg', 'tiff'].
    indexOf(ext.toLowerCase()) !== -1;
};
