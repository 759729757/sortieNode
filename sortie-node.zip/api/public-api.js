
const moment = require('moment')
const mongoose = require('../mongoose')
const Article = mongoose.model('article')
const User = mongoose.model('User')
const About = mongoose.model('about')
const Banner = mongoose.model('banner')
const Magazine = mongoose.model('magazine')
const config = require('../config');//配置文件
const https= require('https');

exports.loginByCode = async (req,res)=>{
    console.log('wx_appid',config.appid+"&secret="+config.appsecret)
    var code = req.query.code || false;
    if (!code){
        res.jsonp({
            status:40001,mess:'缺少必要字段'//缺了code
        });return false;//filtration invalid request
    }
    if(code){
        try {
            var x='';//wx response;
            https.get("https://api.weixin.qq.com/sns/jscode2session?appid="
                + config.appid+"&secret="+config.appsecret+"&js_code="+code
                +"&grant_type=authorization_code",
                function(res1) {
                    res1.on('data',function(d){
                        x = JSON.parse(d.toString());
                        console.log(x)
                        var openid = x.openid;
                        // console.log('user info:'+ x.toString(),openid);
                        if(openid!=undefined){
                            //get openid success!
                            User.findOne({openId:openid}, function (err, user) {
                                if (err)next(err);
                                // console.log('get wx info:',user);
                                if(user){
                                    let content = {openid:openid,_id:user._id}; // 要生成token的主题信息
                                    let secretOrPrivateKey = global.tokenKey;// 这是加密的key（密钥）
                                    let token = jwt.sign(content, secretOrPrivateKey, {
                                        expiresIn: 60*60*4  // 4小时过期
                                    });
                                    res.jsonp({status:1,mess:'ok',token:token,user:user}) //返回token
                                }else {
                                    //首次登陆，自动注册用户
                                    User.create({
                                        openId:openid
                                    },function (err, doc) {
                                        let content = {openid:openid,_id:doc._id}; // 要生成token的主题信息
                                        let secretOrPrivateKey = global.tokenKey;// 这是加密的key（密钥）
                                        let token = jwt.sign(content, secretOrPrivateKey, {
                                            expiresIn: 60*60*4  // 4小时过期
                                        });
                                        res.jsonp({status:1,mess:'register ok',token:token,user:doc}) //返回token
                                    });
                                }
                            });
                        }else{
                            //did not get openid;
                            console.log("获取不到openid :"+ x.errcode);
                            res.jsonp({status:-1,mess:'no openid'});
                            return false;
                        }
                    })
                }).on('error', function(e) {
                //https get fail;
                console.log("微信登陆失败: " + e.message);
                res.jsonp({status:-1,mess:'error,try again'});
            });
        }catch (e) {
            console.log(e)
        }

    }
};

exports.updateUserInfo = (req,res)=>{
    var body = req.body;
    console.log('updateUserInfo',body.nickName);
    User.findOneAndUpdate(
        {openId:body.userInfo.openid},
        {
            avatarUrl: body.avatarUrl,
            city: body.city,
            gender: body.gender,
            nickName: body.nickName,
            province: body.province,
            systemInfo:body.systemInfo
        },
        function (err, doc) {
            res.jsonp({status:1,mess:'ok',data:doc})
        })
}

exports.fetchAbout = (req,res)=>{
    var query = req.query;
    About.findOne(query)
        .then(result => {
            return res.json({
                code: 200,
                mess: '查询成功',
                data: result
            })
        })
}

exports.fetchBanner = (req,res)=>{
    var query = req.query;
    Banner.findOne(query)
        .then(result => {
            return res.json({
                code: 200,
                mess: '查询成功',
                data: result
            })
        })
}

exports.fetchNews = (req,res)=>{
    var query = req.query;
    console.log(req.path,'的参数：',req.query)
    var page = query.page || 1,
        limit = query.limit || 10;
    page --;
    delete query['page'];
    delete query['limit'];
    delete query['userInfo'];

    Article.find(query)
        .sort({ranking:-1})
        .skip(page*limit)
        .limit(limit)
        .then(result => {
            return res.json({
                code: 200,status:1,
                mess: '查询成功',
                data: result
            })
        })
};
exports.fetchMagazine = (req,res)=>{
    var query = req.query;
    console.log(req.path,'的参数：',req.query)
    var page = query.page || 1,
        limit = query.limit || 10;
    page --;
    delete query['page'];
    delete query['limit'];
    delete query['userInfo'];
    delete query['token'];



    Magazine.find(query)
        .sort({ranking:-1})
        .skip(page*limit)
        .limit(limit)
        .then(result => {
            return res.json({
                code: 200,status:1,
                mess: '查询成功',
                data: result
            })
        })
};

